package com.slk.task20.jacksonAnnotation1;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonIdentityInfo15 {

	/**
	 * @param args
	 * @throws JsonProcessingException 
	 */
	public static void main(String[] args) throws JsonProcessingException {
		// TODO Auto-generated method stub
		ObjectMapper mapper = new ObjectMapper();     
	      Std152 student = new Std152(1,13, "amit");
	      Book2 book1 = new Book2(1,"Learn HTML", student);
	      Book book2 = new Book(2,"Learn JAVA", student);

	      student.addBook(book1);
	      student.addBook(book2);

	      String jsonString = mapper
	         .writerWithDefaultPrettyPrinter()
	         .writeValueAsString(book1);
	      System.out.println(jsonString);
	   }
	}
	@JsonIdentityInfo(
	   generator = ObjectIdGenerators.PropertyGenerator.class,
	   property = "id")
	class Std152 { 
	   public int id;
	   public int rollNo;
	   public String name;
	   public List<Book> books;
	   
	   Std152(int id, int rollNo, String name){
	      this.id = id;
	      this.rollNo = rollNo;
	      this.name = name;
	      this.books = new ArrayList<Book>();
	   }
	   public void addBook(Book2 book1) {
		// TODO Auto-generated method stub
		
	}
	public void addBook(Book book){
	      books.add(book);
	   }
	}
	@JsonIdentityInfo(
	   generator = ObjectIdGenerators.PropertyGenerator.class,
	   property = "id")
	class Book2{
	   public int id;
	   public String name;

	   Book2(int id, String name, Student owner){
	      this.id = id;
	      this.name = name;
	      this.owner = owner;
	   }
	  
	public Student owner;
	}
