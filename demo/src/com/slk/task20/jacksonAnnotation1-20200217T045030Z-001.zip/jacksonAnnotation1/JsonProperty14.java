package com.slk.task20.jacksonAnnotation1;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonProperty14 {

	/**
	 * @param args
	 * @throws JsonProcessingException 
	 * @throws JsonMappingException 
	 */
	public static void main(String[] args) throws JsonMappingException, JsonProcessingException {
		// TODO Auto-generated method stub

		ObjectMapper mapper = new ObjectMapper();
	      String json = "{\"id\" : 1}";
	      Student141 student = mapper.readerFor(Student141.class).readValue(json);
	      System.out.println(student.getTheId());
	   }
	}
	class Student141 {
	   private int id;
	   Student141(){}
	   Student141(int id){
	      this.id = id;
	   }
	   @JsonProperty("id")
	   public int getTheId() {
	      return id;
	   }
	   @JsonProperty("id")
	   public void setTheId(int id) {
	      this.id = id;
	   }   
	}
