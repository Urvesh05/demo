package com.slk.task20.jacksonAnnotation1;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIdentityInfo;
import com.fasterxml.jackson.annotation.ObjectIdGenerators;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class jsonIdentityInfo13 {

	/**
	 * @param args
	 * @throws JsonProcessingException 
	 */
	public static void main(String[] args) throws JsonProcessingException {
		// TODO Auto-generated method stub

		ObjectMapper mapper = new ObjectMapper();     
	      St student = new St(1,13, "Mark");
	      Bo book1 = new Bo(1,"Learn HTML", student);
	      Bo book2 = new Bo(2,"Learn JAVA", student);

	      student.addBook(book1);
	      student.addBook(book2);

	      String jsonString = mapper
	         .writerWithDefaultPrettyPrinter()
	         .writeValueAsString(book1);
	      System.out.println(jsonString);
	   }
	}
	@JsonIdentityInfo(
	   generator = ObjectIdGenerators.PropertyGenerator.class,
	   property = "id")
	class St { 
	   public int id;
	   public int rollNo;
	   public String name;
	   public List<Book> books;
	   
	   St(int id, int rollNo, String name){
	      this.id = id;
	      this.rollNo = rollNo;
	      this.name = name;
	      this.books = new ArrayList<Book>();
	   }
	   public void addBook(Bo book1) {
		// TODO Auto-generated method stub
		
	}
	public void addBook(Book book){
	      books.add(book);
	   }
	}
	@JsonIdentityInfo(
	   generator = ObjectIdGenerators.PropertyGenerator.class,
	   property = "id")
	class Bo{
	   public int id;
	   public String name;

	   Bo(int id, String name, St student){
	      this.id = id;
	      this.name = name;
	      this.owner = student;
	   }
	   public St owner;
	}