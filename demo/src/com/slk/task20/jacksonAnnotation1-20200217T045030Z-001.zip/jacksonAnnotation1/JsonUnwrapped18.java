package com.slk.task20.jacksonAnnotation1;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonUnwrapped;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonUnwrapped18 {

	/**
	 * @param args
	 * @throws ParseException 
	 * @throws JsonProcessingException 
	 */
	public static void main(String[] args) throws ParseException, JsonProcessingException {
		// TODO Auto-generated method stub

		 ObjectMapper mapper = new ObjectMapper();
	      SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
	      Date date = simpleDateFormat.parse("20-12-1984");
	      Student18.Name name = new Student18.Name();
	      name.first = "Jagu";
	      name.last = "Dhaval";
	      Student18 student = new Student18(1, name);
	      String jsonString = mapper
	         .writerWithDefaultPrettyPrinter()
	         .writeValueAsString(student);
	      System.out.println(jsonString);
	   }
	}
	class Student18 {
	   public int id;   
	   @JsonUnwrapped
	   public Name name;
	   Student18(int id, Name name){
	      this.id = id;
	      this.name = name;
	   }
	   static class Name {
	      public String first;
	      public String last;
	   }
	}
